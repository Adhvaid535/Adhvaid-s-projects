
<?php
$conn = new mysqli("localhost", "root", "", "leave_system");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employee_id = $_POST["employee_id"];
    $start_date = $_POST["start_date"];
    $end_date = $_POST["end_date"];
    $reason = $_POST["reason"];

    $sql = "INSERT INTO leave_requests (employee_id, start_date, end_date, reason, status)
            VALUES ('$employee_id', '$start_date', '$end_date', '$reason', 'Pending')";
    $conn->query($sql);
    echo "Leave request submitted!";
}
?>

<h2>Apply for Leave</h2>
<form method="post">
    Employee ID: <input type="text" name="employee_id"><br>
    Start Date: <input type="date" name="start_date"><br>
    End Date: <input type="date" name="end_date"><br>
    Reason: <input type="text" name="reason"><br>
    <input type="submit" value="Apply">
</form>
