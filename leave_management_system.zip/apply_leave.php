
<?php
$conn = new mysqli("localhost", "root", "", "leave_system");

$employee_id = $_POST['employee_id'];
$leave_type = $_POST['leave_type'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$reason = $_POST['reason'];

$sql = "INSERT INTO leave_requests (employee_id, leave_type, start_date, end_date, reason, status)
        VALUES ('$employee_id', '$leave_type', '$start_date', '$end_date', '$reason', 'Pending')";

if ($conn->query($sql) === TRUE) {
    echo "Leave request submitted successfully.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
