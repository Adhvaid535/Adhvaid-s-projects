
<?php
$conn = new mysqli("localhost", "root", "", "leave_system");

if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $status = $_GET['action'] == 'approve' ? 'Approved' : 'Rejected';
    $conn->query("UPDATE leave_requests SET status='$status' WHERE id=$id");
}

$result = $conn->query("SELECT * FROM leave_requests");
echo "<h2>Manager Dashboard</h2>";
echo "<table border='1'><tr><th>ID</th><th>Employee</th><th>Start</th><th>End</th><th>Reason</th><th>Status</th><th>Action</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['employee_id']}</td>
            <td>{$row['start_date']}</td>
            <td>{$row['end_date']}</td>
            <td>{$row['reason']}</td>
            <td>{$row['status']}</td>
            <td>
                <a href='?action=approve&id={$row['id']}'>Approve</a> | 
                <a href='?action=reject&id={$row['id']}'>Reject</a>
            </td>
          </tr>";
}
echo "</table>";
?>
