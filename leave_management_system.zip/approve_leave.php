
<?php
$conn = new mysqli("localhost", "root", "", "leave_system");

$request_id = $_GET['id'];
$action = $_GET['action'];

$status = $action == 'approve' ? 'Approved' : 'Rejected';

$sql = "UPDATE leave_requests SET status='$status' WHERE id=$request_id";

if ($conn->query($sql) === TRUE) {
    echo "Leave request has been " . $status . ".";
} else {
    echo "Error updating record: " . $conn->error;
}
$conn->close();
?>
