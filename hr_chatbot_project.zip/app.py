
from flask import Flask, render_template, request, jsonify
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer

app = Flask(__name__)

chatbot = ChatBot('HRBot',
                  storage_adapter='chatterbot.storage.SQLStorageAdapter',
                  logic_adapters=['chatterbot.logic.BestMatch'],
                  database_uri='sqlite:///hr_bot_db.sqlite3')

trainer = ListTrainer(chatbot)
trainer.train([
    "What is the leave policy?",
    "Our leave policy allows 20 days of paid leave annually.",
    "How do I apply for leave?",
    "Use the HR portal under 'Leave Management'.",
    "When do we get paid?",
    "Salaries are credited on the last working day of each month.",
    "What benefits does the company offer?",
    "We offer health insurance, bonuses, and paid time off.",
    "Who to contact for payroll issues?",
    "Email payroll@company.com for help."
])

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["GET"])
def get_bot_response():
    user_text = request.args.get('msg')
    response = str(chatbot.get_response(user_text))
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
